
package com.mycompany.guessinggame;
import java.util.Random;
import java.util.Scanner;
public class GuessingGame {

    public static void main(String[] args) {
       
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Generate a random number between 1 and 100
        int numberToGuess = random.nextInt(100) + 1;
        int userGuess = 0;
        int attemptCount = 0;

        System.out.println("Welcome to the Guess the Number game!");
        System.out.println("I have selected a number between 1 and 100. Try to guess it.");

        // Loop until the user guesses the number
        while (userGuess != numberToGuess) {
            System.out.print("Enter your guess: ");
            userGuess = scanner.nextInt();
            attemptCount++;

            // Provide feedback to the user
            if (userGuess < numberToGuess) {
                System.out.println("Too low! Try again.");
            } else if (userGuess > numberToGuess) {
                System.out.println("Too high! Try again.");
            } else {
                System.out.println("Congratulations! You guessed the number.");
                System.out.printf("It took you %d attempts to guess the number.%n", attemptCount);
            }
        }

        // Close the scanner
        scanner.close();
    }
}
    
